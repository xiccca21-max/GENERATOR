Пакет для валидатора: по 10 PDF, которые прошли живой @proton_pdf_bot.
Папки = банк / подметод. Имя файла: NN__Банк__Метод__оригинал.pdf

Есть Proton PASS:
  T-Bank  / SBP               10 шт   источник: _test20_tbank_sbp_proton33
  T-Bank  / Phone             10 шт   источник: _test20_tbank_phone_proton04
  T-Bank  / Card_to_T-Bank    10 шт   источник: _test20_tbank_card_tbank_proton02
  Alfa    / SBP               10 шт   источник: _test20_alfa_sbp_proton21
  Alfa    / Phone             10 шт   источник: _test20_alfa_phone_proton23
  Alfa    / Card              10 шт   источник: _test20_alfa_card_proton22
  Sber    / SBP               10 шт   источник: _test20_sber_sbp_proton23
  Sber    / Phone             10 шт   источник: proton04+03+02

Нет 10 Proton PASS (не подкладывал OnlyPDF/Fraudex):
  T-Bank  / Nocomm            — Proton-папки _test20_tbank_nocomm_proton01..03 пустые
  T-Bank  / Card_to_Sber      — Нет Proton 20/20 (есть только OnlyPDF/Fraudex strict50)
  T-Bank  / Statement         — Метод закрыт, Proton-пачки нет
  Alfa    / Statement         — Нет Proton PASS-пачки
  Sber    / Card              — Метод закрыт (нет чистого донора)

Как собирали: PDF из выходных папок gen_onlypdf30_* --gate proton --strict.
Реджекты (*_rejects, *FAKE*) не брали.
Sber Phone: склейка трёх серий (04=4, 03=2, 02=7) — отдельной полной 20/20 ещё нет.
